<?php
// add_action( 'wp_enqueue_scripts', 'enqueue_child_theme_styles', PHP_INT_MAX);
// function enqueue_child_theme_styles() {
//   wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
// }

add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles',999 );
  function theme_enqueue_styles() {
	  
	$parent_style = 'james-style';
	  
	wp_enqueue_style( 'james-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'james-style', get_template_directory_uri() . '/css/layouts1.css' );
	wp_enqueue_style( 'james-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		array( $parent_style )
	);
}
?>